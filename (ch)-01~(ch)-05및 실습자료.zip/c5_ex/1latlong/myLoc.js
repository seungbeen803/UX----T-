/* myLoc.js */


window.onload = getMyLocation;

//추가1









//추가2








//추가3

